package springbootmybatisplus;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-17 22:33:21
 **/
public class Mainapp {
}
