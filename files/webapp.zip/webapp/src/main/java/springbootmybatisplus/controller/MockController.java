package springbootmybatisplus.controller;

import com.google.common.collect.Maps;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/mock")
public class MockController {

	@GetMapping("/health/check")
	public Object healthCheck() {
		return "ok";
	}

	@PostMapping("/batch/insert")
	public Object batchInsert() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("code", 20000);
		map.put("msg", "success");
		return map;
	}

	
}
