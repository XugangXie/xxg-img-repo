package mywebapp.service;

import com.alibaba.fastjson2.JSON;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import mywebapp.entity.document.DocObj;
import mywebapp.entity.request.DocFilterRequest;
import mywebapp.entity.request.MultiDocFilterRequest;
import mywebapp.entity.response.DocFilterResponse;
import mywebapp.enums.AppEnums;
import mywebapp.feign.api.lis.LisApi;
import mywebapp.utils.http.v1.handler.HttpPostHandler;
import mywebapp.utils.http.v2.MyHttpClientUtils;
import mywebapp.utils.http.v2.Response;
import mywebapp.utils.xml.XmlDomUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-19 18:52:59
 **/
@Slf4j
@Service
@RequiredArgsConstructor
public class LisAdapterService {

   private final LisApi lisApi;

   private final HttpPostHandler httpPostHandler;

   private final ObjectMapper objectMapper;


   @Value("${remote.lis.url}")
   private String serviceLisUrl;

   //do filter for document by LotId, DocumentId  .etc
   public DocFilterResponse doDocFilter(DocFilterRequest docFilterRequest) {
      //1.POST Request to count document
      int count = 0;
      try {
         String url = String.format("%s/documentstore/rest/document/count/%s/", serviceLisUrl, docFilterRequest.getDocumentType());

//         Map<String, Object> bodyMap = objectMapper.convertValue(docFilterRequest, Map.class);
//         HttpResult httpResult = httpPostHandler.doPost(url, bodyMap, 10);
//         String resultContent = httpResult.getResponse().getContent();

         String jsonBody = objectMapper.writeValueAsString(docFilterRequest);
         Response<String> httpResponse = MyHttpClientUtils.postRequest(url, jsonBody, String.class);
         if (Objects.nonNull(httpResponse) && httpResponse.getIsSuccess()) {
            String resultContent = httpResponse.getOutput();
            log.info("1.count ADELler={}", resultContent);
            if (StringUtils.isNotBlank(resultContent)) {
               count = Integer.parseInt(resultContent);
            }
         }
      } catch (Exception e) {
         log.error(e.getMessage(), e);
      }

      //2.POST Request to list document
      List<DocObj> docObjList = Collections.emptyList();
       try {
           if (count > 0) {
              String url = String.format("%s/documentstore/rest/document/list/%s/", serviceLisUrl, docFilterRequest.getDocumentType());
              String jsonBody = objectMapper.writeValueAsString(docFilterRequest);
              Response<String> httpResponse = MyHttpClientUtils.postRequest(url, jsonBody, String.class);
              docObjList = JSON.parseArray(httpResponse.getOutput(), DocObj.class);
              log.info("2.httpResponse={}", docObjList);

           }
       } catch (Exception e) {
          log.error(e.getMessage(), e);
       }

       return DocFilterResponse.builder().docList(docObjList).build();
   }

   public DocFilterResponse doDocFilter(AppEnums.DocumentTypeEnum documentTypeEnum, DocFilterRequest docFilterRequest) {
      docFilterRequest.setDocumentType(documentTypeEnum.getDocumentType());
      return doDocFilter(docFilterRequest);
   }

   public String fileContentByDownload(String docKey) {
      String fileContent =  null;
      try {
         String url = String.format("%s/%s", serviceLisUrl, docKey);
         fileContent = MyHttpClientUtils.getRequest(url);
      } catch (Exception e) {
         log.error(e.getMessage(), e);
      }
      return fileContent;
   }

   public void generateDummy(MultiDocFilterRequest multiDocFilterRequest) {
       try {
           //1.download ler file by filter
           DocFilterRequest lerDocFilterRequest = multiDocFilterRequest.getLerDocFilter();
           DocFilterResponse lerDocFilterResponse = doDocFilter(AppEnums.DocumentTypeEnum.LER, lerDocFilterRequest);
           List<DocObj> lerDocList = lerDocFilterResponse.getDocList();
           String lerXmlContent = "";
           if (CollectionUtils.isNotEmpty(lerDocList)) {
              DocObj lerDocObj = lerDocList.get(0);
              if (Objects.nonNull(lerDocObj) && Objects.nonNull(lerDocObj.getKey())) {
                 String lerDocKey = lerDocObj.getKey().getCanonicalKey();
                 lerDocKey = URLEncoder.encode(lerDocKey, "UTF-8");
                 String docDownloadUrl = String.format("%s/documentstore/rest/document/ADELler/%s", serviceLisUrl, lerDocKey);
                 lerXmlContent = MyHttpClientUtils.getRequest(docDownloadUrl);
              }
           }

           //2.download metrology file by filter
           DocFilterRequest metroLogyDocFilterRequest = multiDocFilterRequest.getMetrologyDocFilter();
           DocFilterResponse metrologyDocFilterResponse = doDocFilter(AppEnums.DocumentTypeEnum.METROLOGY, metroLogyDocFilterRequest);
           List<DocObj> metrologyDocList = metrologyDocFilterResponse.getDocList();
           String metrologyXmlContent = "";
           if (CollectionUtils.isNotEmpty(metrologyDocList)) {
               DocObj metrologyDocObj = metrologyDocList.get(0);
               if (Objects.nonNull(metrologyDocObj) && Objects.nonNull(metrologyDocObj.getKey())) {
                   String metrologyDocKey = metrologyDocObj.getKey().getCanonicalKey();
                   metrologyDocKey = URLEncoder.encode(metrologyDocKey, "UTF-8");
                   String docDownloadUrl = String.format("%s/documentstore/rest/document/ADELmetrology/%s", serviceLisUrl, metrologyDocKey);
                   metrologyXmlContent = MyHttpClientUtils.getRequest(docDownloadUrl);
               }
           }


           //3.
           List<String> resultWaferIdList = getDistinctWaferIdList(lerXmlContent);
           //4.
           replaceAndRemoveWaferResult(resultWaferIdList, metrologyXmlContent);
           log.info("==================");
       } catch (Exception e) {
          log.error(e.getMessage(), e);
       }

   }


   private List<String> getDistinctWaferIdList(String lerXmlContent) {
        List<String> resultWaferIdList = Lists.newArrayList();

        try {
            log.info("1.begin load ler xml.");
            Document lerDocument = XmlDomUtil.loadXmlFromString(lerXmlContent);
            Element rootElement = lerDocument.getDocumentElement();

            NodeList waferResultNodeList = XmlDomUtil.getNodeListByPath(lerDocument, "//Report/Results/WaferResultList/elt");
            log.info("2.Firstly, get WaferResultList size={}", waferResultNodeList.getLength());

            List<Element> eltElementList = Lists.newArrayList();
            for (int i = 0; i < waferResultNodeList.getLength(); i++) {
                Node eltNode = waferResultNodeList.item(i);
                if (eltNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eltElement = (Element) eltNode;
                    eltElementList.add(eltElement);
                }
            }

            LinkedHashMap<String, List<Element>> waferGoupByChuckMap = eltElementList.stream()
                    .sorted((ele1, ele2) -> ele1.getTextContent().compareTo(ele2.getTextContent()))
                    .collect(Collectors.groupingBy(XmlDomUtil::getChuckId, LinkedHashMap::new, Collectors.toList()));
            log.info("waferGoupByChuckMap={}", waferGoupByChuckMap);

            for (Map.Entry<String, List<Element>> entry : waferGoupByChuckMap.entrySet()) {
                List<Element> elementListInOneChuck = entry.getValue();
                Element firstEltElement = elementListInOneChuck.get(0);

                String waferId = XmlDomUtil.getElementText(firstEltElement, "WaferId");
                resultWaferIdList.add(waferId);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return resultWaferIdList;
    }

    private void replaceAndRemoveWaferResult(List<String> resultWaferIdList, String metrologyXmlContent) {
        try {
            Document metrologyDocument = XmlDomUtil.loadXmlFromString(metrologyXmlContent);

            //1.find //MetrologyReport/Header/DocumentId and set uuid value
            NodeList documentIdNode = XmlDomUtil.getNodeListByPath(metrologyDocument, "//MetrologyReport/Header/DocumentId");
            if (Objects.nonNull(documentIdNode) &&  documentIdNode.getLength() > 0) {
                Element documentIdElement =  (Element) documentIdNode.item(0);
                String newlyUuid = UUID.randomUUID().toString();
                documentIdElement.setTextContent(newlyUuid);
                log.info(">>>1.reset newly uuid={}", newlyUuid);
            }

            //2.find //MetrologyReport/Results/WaferResultList/WaferResult nodelist
            NodeList waferResultListNodeList = XmlDomUtil.getNodeListByPath(metrologyDocument, "//MetrologyReport/Results/WaferResultList");
            Element waferResultListElement = (Element) waferResultListNodeList.item(0);

            NodeList waferResultNodeList = XmlDomUtil.getNodeListByPath(metrologyDocument, "//MetrologyReport/Results/WaferResultList/WaferResult");
            log.info("waferResultNodeList={}", waferResultNodeList.getLength());

            Element waferResultTemplate = null;
            for (int i = 0; i < waferResultNodeList.getLength(); i++) {
                Element waferResultElement = (Element) waferResultNodeList.item(i);
                if (i == 0) {
                    waferResultTemplate  = waferResultElement;
                } else {
                    waferResultElement.getParentNode().removeChild(waferResultElement);
                }
            }

            if (Objects.nonNull(waferResultTemplate) && CollectionUtils.isNotEmpty(resultWaferIdList)) {
                String waferId1FromLer = resultWaferIdList.get(0);
                //2.1 set WaferId followed by WaferId in Ler file
                waferResultTemplate.getElementsByTagName("WaferId").item(0).setTextContent(waferId1FromLer);

                //2.2 set each WaferResult/MeasurementList/Measurement/OverlayMeasurement/ 下的 Overlay/X Overlay/Y   MeasuredOverlay/X  MeasuredOverlay/Y
                NodeList measurementListNodeList = waferResultTemplate.getElementsByTagName("MeasurementList");
                if (Objects.nonNull(measurementListNodeList) && measurementListNodeList.getLength() > 0) {
                    Element measurementListElement = (Element) measurementListNodeList.item(0);
                    NodeList measurementNodeList = measurementListElement.getElementsByTagName("Measurement");
                    if (Objects.nonNull(measurementNodeList) && measurementNodeList.getLength() > 0) {
                        for (int j = 0; j < measurementNodeList.getLength(); j++) {
                            Element measurement = (Element) measurementNodeList.item(j);
                            NodeList overlayMeasurementNode = measurement.getElementsByTagName("OverlayMeasurement");
                            if (Objects.nonNull(overlayMeasurementNode) && overlayMeasurementNode.getLength() > 0) {
                                Element overlayMeasurementTag = (Element) overlayMeasurementNode.item(0);
                                NodeList overlayElementNode = overlayMeasurementTag.getElementsByTagName("Overlay");
                                if (Objects.nonNull(overlayElementNode) && overlayElementNode.getLength() > 0) {
                                    Element overlayElementTag = (Element) overlayElementNode.item(0);
                                    overlayElementTag.getElementsByTagName("X").item(0).setTextContent("0");
                                    overlayElementTag.getElementsByTagName("Y").item(0).setTextContent("0");
                                }



                                NodeList measuredOverlayElementNode = overlayMeasurementTag.getElementsByTagName("MeasuredOverlay");
                                if (Objects.nonNull(measuredOverlayElementNode) && measuredOverlayElementNode.getLength() > 0) {
                                    Element measuredOverlayElementTag =  (Element) measuredOverlayElementNode.item(0);
                                    measuredOverlayElementTag.getElementsByTagName("X").item(0).setTextContent("0");
                                    measuredOverlayElementTag.getElementsByTagName("Y").item(0).setTextContent("0");
                                }
                            }
                        }
                    }
                }


                //2.3 add <WaferResult> if has two chuck
                if (CollectionUtils.isNotEmpty(resultWaferIdList) && resultWaferIdList.size() > 1) {
                    String waferId2FromLer = resultWaferIdList.get(1);
                    Element waferResultTemplateCopy = (Element) waferResultTemplate.cloneNode(true);
                    waferResultTemplateCopy.getElementsByTagName("WaferId").item(0).setTextContent(waferId2FromLer);
                    waferResultListElement.appendChild(waferResultTemplateCopy);
                }
            }

            //3.save new metrology xml file
            String dummyMetrologyPath = String.format("C:/dev/code/webapp/src/main/resources/asml/metrology/dummy-%d.xml", System.currentTimeMillis());
            XmlDomUtil.saveDocumentToFile(metrologyDocument, dummyMetrologyPath);
            log.info("save updated xml success.");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }


}
