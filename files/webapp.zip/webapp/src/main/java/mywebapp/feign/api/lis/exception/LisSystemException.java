package mywebapp.feign.api.lis.exception;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-19 17:37:58
 **/
public class LisSystemException {


}
