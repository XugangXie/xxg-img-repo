package mywebapp.feign.api.lis.interceptor;

import feign.RequestInterceptor;
import feign.RequestTemplate;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-19 18:25:42
 **/
public class ListApiInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate requestTemplate) {

    }
}
