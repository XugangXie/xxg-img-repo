/**
 * LIS系统的API接口
 */
package mywebapp.feign.api.lis;