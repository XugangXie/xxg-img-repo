package mywebapp.feign.api.lis;

import mywebapp.feign.api.lis.config.LisConfiguration;
import mywebapp.entity.request.DocFilterRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-19 17:38:21
 **/
@FeignClient(name = "lis-client", url = "${remote.lis.url}", configuration = {LisConfiguration.class})
public interface LisApi {

    //count docs by filter
    @PostMapping(value = "documentstore/rest/document/count/ADELler/")
    public Object countADELler(@RequestBody DocFilterRequest docFilterRequest);

    //list docs by filter
    @PostMapping(value = "/documentstore/rest/document/list/ADELler/")
    public Object listADELler(@RequestBody DocFilterRequest docFilterRequest);

    //download doc


    //upload doc


}
