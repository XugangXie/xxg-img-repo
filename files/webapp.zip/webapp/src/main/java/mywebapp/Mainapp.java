package mywebapp;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import mywebapp.utils.xml.XmlDomUtil;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 18/6/2025 下午4:51 
 */
@Slf4j
public class Mainapp {

    public static void main(String[] args) {
        Mainapp mainapp = new Mainapp();

        //1.从ADEL ler文件中找到每个chuck下的第一个waferId
        List<String> resultWaferIdList = mainapp.getDistinctWaferIdList();
        if (CollectionUtils.isNotEmpty(resultWaferIdList)) {
            //2.将ADEL metrology 文件中的documentId使用uuid重新赋值
            //3.找到第一个 //MetrologyReport/Results/WaferResultList/WaterResult 节点，作为模板节点
            //4.更新模板节点的 WaferId、MeasurementList下的每个Measurement的 OverlayMeasurement/Overlay/X,Y  OverlayMeasurement/MeasuredOverlay/X,Y 的值，都是设置为0
            mainapp.replaceAndRemoveWaferResult(resultWaferIdList);
        }
    }


    public List<String> getDistinctWaferIdList() {
        List<String> resultWaferIdList = Lists.newArrayList();

        String lerPath = "asml/ler/Ler0_79e9c490.xml";
        try {
            log.info("1.begin load ler xml.");
            Document lerDocument = XmlDomUtil.loadXmlFromClassPath(lerPath);
            Element rootElement = lerDocument.getDocumentElement();

            NodeList waferResultNodeList = XmlDomUtil.getNodeListByPath(lerDocument, "//Report/Results/WaferResultList/elt");
            log.info("2.Firstly, get WaferResultList size={}", waferResultNodeList.getLength());

            List<Element> eltElementList = Lists.newArrayList();
            for (int i = 0; i < waferResultNodeList.getLength(); i++) {
                Node eltNode = waferResultNodeList.item(i);
                if (eltNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eltElement = (Element) eltNode;
                    eltElementList.add(eltElement);
                }
            }

            LinkedHashMap<String, List<Element>> waferGoupByChuckMap = eltElementList.stream()
                    .sorted((ele1, ele2) -> ele1.getTextContent().compareTo(ele2.getTextContent()))
                    .collect(Collectors.groupingBy(XmlDomUtil::getChuckId, LinkedHashMap::new, Collectors.toList()));
            log.info("waferGoupByChuckMap={}", waferGoupByChuckMap);

            for (Map.Entry<String, List<Element>> entry : waferGoupByChuckMap.entrySet()) {
                List<Element> elementListInOneChuck = entry.getValue();
                Element firstEltElement = elementListInOneChuck.get(0);

                String waferId = XmlDomUtil.getElementText(firstEltElement, "WaferId");
                resultWaferIdList.add(waferId);
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

        return resultWaferIdList;
    }

    public void replaceAndRemoveWaferResult(List<String> resultWaferIdList) {
        String metrologyPath = "asml/metrology/1d4ff996-5a9b-41ad-ad4b-970dfd19e11f.xml";
        try {
            Document metrologyDocument = XmlDomUtil.loadXmlFromClassPath(metrologyPath);

            //1.find //MetrologyReport/Header/DocumentId and set uuid value
            NodeList documentIdNode = XmlDomUtil.getNodeListByPath(metrologyDocument, "//MetrologyReport/Header/DocumentId");
            if (Objects.nonNull(documentIdNode) &&  documentIdNode.getLength() > 0) {
                Element documentIdElement =  (Element) documentIdNode.item(0);
                String newlyUuid = UUID.randomUUID().toString();
                documentIdElement.setTextContent(newlyUuid);
                log.info(">>>1.reset newly uuid={}", newlyUuid);
            }

            //2.find //MetrologyReport/Results/WaferResultList/WaferResult nodelist
            NodeList waferResultListNodeList = XmlDomUtil.getNodeListByPath(metrologyDocument, "//MetrologyReport/Results/WaferResultList");
            Element waferResultListElement = (Element) waferResultListNodeList.item(0);

            NodeList waferResultNodeList = XmlDomUtil.getNodeListByPath(metrologyDocument, "//MetrologyReport/Results/WaferResultList/WaferResult");
            log.info("waferResultNodeList={}", waferResultNodeList.getLength());

            Element waferResultTemplate = null;
            for (int i = 0; i < waferResultNodeList.getLength(); i++) {
                Element waferResultElement = (Element) waferResultNodeList.item(i);
                if (i == 0) {
                    waferResultTemplate  = waferResultElement;
                } else {
                    waferResultElement.getParentNode().removeChild(waferResultElement);
                }
            }

            if (Objects.nonNull(waferResultTemplate) && CollectionUtils.isNotEmpty(resultWaferIdList)) {
                String waferId1FromLer = resultWaferIdList.get(0);
                //2.1 set WaferId followed by WaferId in Ler file
                waferResultTemplate.getElementsByTagName("WaferId").item(0).setTextContent(waferId1FromLer);

                //2.2 set each WaferResult/MeasurementList/Measurement/OverlayMeasurement/ 下的 Overlay/X Overlay/Y   MeasuredOverlay/X  MeasuredOverlay/Y
                NodeList measurementListNodeList = waferResultTemplate.getElementsByTagName("MeasurementList");
                if (Objects.nonNull(measurementListNodeList) && measurementListNodeList.getLength() > 0) {
                    Element measurementListElement = (Element) measurementListNodeList.item(0);
                    NodeList measurementNodeList = measurementListElement.getElementsByTagName("Measurement");
                    if (Objects.nonNull(measurementNodeList) && measurementNodeList.getLength() > 0) {
                        for (int j = 0; j < measurementNodeList.getLength(); j++) {
                            Element measurement = (Element) measurementNodeList.item(j);
                            NodeList overlayMeasurementNode = measurement.getElementsByTagName("OverlayMeasurement");
                            if (Objects.nonNull(overlayMeasurementNode) && overlayMeasurementNode.getLength() > 0) {
                                Element overlayMeasurementTag = (Element) overlayMeasurementNode.item(0);
                                NodeList overlayElementNode = overlayMeasurementTag.getElementsByTagName("Overlay");
                                if (Objects.nonNull(overlayElementNode) && overlayElementNode.getLength() > 0) {
                                    Element overlayElementTag = (Element) overlayElementNode.item(0);
                                    overlayElementTag.getElementsByTagName("X").item(0).setTextContent("0");
                                    overlayElementTag.getElementsByTagName("Y").item(0).setTextContent("0");
                                }



                                NodeList measuredOverlayElementNode = overlayMeasurementTag.getElementsByTagName("MeasuredOverlay");
                                if (Objects.nonNull(measuredOverlayElementNode) && measuredOverlayElementNode.getLength() > 0) {
                                    Element measuredOverlayElementTag =  (Element) measuredOverlayElementNode.item(0);
                                    measuredOverlayElementTag.getElementsByTagName("X").item(0).setTextContent("0");
                                    measuredOverlayElementTag.getElementsByTagName("Y").item(0).setTextContent("0");
                                }
                            }
                        }
                    }
                }


                //2.3 add <WaferResult> if has two chuck
                if (CollectionUtils.isNotEmpty(resultWaferIdList) && resultWaferIdList.size() > 1) {
                    String waferId2FromLer = resultWaferIdList.get(1);
                    Element waferResultTemplateCopy = (Element) waferResultTemplate.cloneNode(true);
                    waferResultTemplateCopy.getElementsByTagName("WaferId").item(0).setTextContent(waferId2FromLer);
                    waferResultListElement.appendChild(waferResultTemplateCopy);
                }
            }

            //3.save new metrology xml file
            String dummyMetrologyPath = "C:/dev/code/webapp/src/main/resources/asml/metrology/dummy.xml";
            XmlDomUtil.saveDocumentToFile(metrologyDocument, dummyMetrologyPath);
            log.info("save updated xml success.");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }

    }

}
