package mywebapp.controller;

import lombok.RequiredArgsConstructor;
import mywebapp.entity.request.DocFilterRequest;
import mywebapp.entity.request.MultiDocFilterRequest;
import mywebapp.entity.response.DocFilterResponse;
import mywebapp.service.LisAdapterService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-20 09:50:40
 **/
@RestController
@RequestMapping("/lis")
@RequiredArgsConstructor
public class LisAdapterController {

    private final LisAdapterService lisAdapterService;

    @PostMapping(value = "/document/list")
    public DocFilterResponse documentList(@RequestBody DocFilterRequest docFilterRequest) {
        return lisAdapterService.doDocFilter(docFilterRequest);
    }

    @PostMapping(value = "/document/dummy")
    public void documentDummy(@RequestBody MultiDocFilterRequest multiDocFilterRequest) {
        lisAdapterService.generateDummy(multiDocFilterRequest);
    }


}
