package mywebapp.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-19 17:56:29
 **/
public class AppEnums {

    @AllArgsConstructor
    @Getter
    public enum DocumentTypeEnum {
        LER("ADELler"),
        METROLOGY("ADELmetrology"),

        ;
        private String documentType;
    }

    @AllArgsConstructor
    @Getter
    public enum OperatorEnum {
        EQUALS("="),
        LIKE("like"),

        ;
        private String label;
    }


}
