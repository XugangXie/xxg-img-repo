package mywebapp.entity.request;

import lombok.Data;

import java.util.List;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-19 17:46:58
 **/
@Data
public class DocFilterRequest {

    private String documentType;

    private List<FilterCriteria> filterCriteria;

    private int page;
    private int pageSize;
    private List<SortCriteria> sortCriteria;

    @Data
    public static class FilterCriteria {
        private DocumentAttribute documentAttribute;
        private String operator;
    }

    @Data
    public static class DocumentAttribute {
        private String name;
        private String type;
        private String value;
    }

    @Data
    public static class SortCriteria {
        private String direction;
        private String name;
    }
}
