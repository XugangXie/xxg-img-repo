package mywebapp.entity.document;

import lombok.Data;

import java.util.LinkedHashMap;
import java.util.List;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-20 13:03:15
 **/
@Data
public class DocObj {

    private long size;
    private String name;
    private String filename;
    private Long creationDate;
    private Long lastModificationDate;
    private String schemaVersion;
    private Integer documentTypeVersion;
    private String source;
    private DocKey key;
    private LinkedHashMap<String, DocAttribute> attributes;

    @Data
    public static class DocKey {
        private String canonicalKey;
        private String documentType;
        private List<DocAttribute> attributes;
    }

    @Data
    public static class DocAttribute {
        private String type;
        private String name;
        private String value;
    }
}
