package mywebapp.entity.request;

import lombok.Data;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-23 13:09:16
 **/
@Data
public class MultiDocFilterRequest {

    DocFilterRequest lerDocFilter;

    DocFilterRequest metrologyDocFilter;

}
