package mywebapp.entity.response;

import lombok.*;
import mywebapp.entity.document.DocObj;

import java.util.List;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-20 09:52:26
 **/
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocFilterResponse {

    private List<DocObj> docList;

}
