package mywebapp.utils.http.v2;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-20 11:18:43
 **/
@Component
@Slf4j
public class MyHttpClientUtils {

    public static <T> Response<T> postRequest(String uri, String jsonBody, Class<T> rtnType) {
        Response<T> invokeResponse = new Response<T>();
        T rtnOuput = null;
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost postRequest = new  HttpPost(uri);
            postRequest.setHeader(HTTP.CONTENT_TYPE, "application/json");
            StringEntity input = new StringEntity(jsonBody);
            postRequest.setEntity(input);

            HttpResponse response = httpClient.execute(postRequest);
            String output = EntityUtils.toString(response.getEntity(), HTTP.UTF_8);
            rtnOuput = JSONObject.parseObject(output, rtnType);
            invokeResponse.setStatusCode(response.getStatusLine().getStatusCode());
            invokeResponse.setOutput(rtnOuput);

            if (response.getStatusLine().getStatusCode() != 200) {
                invokeResponse.setIsSuccess(false);
            }
            HttpClientUtils.closeQuietly(response);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return invokeResponse;
    }

    public static String getRequest(String uri) {
        String docContent = null;
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(uri);
            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                HttpEntity entity = response.getEntity();
                if (Objects.nonNull(entity)) {
                    docContent = EntityUtils.toString(entity, HTTP.UTF_8);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return docContent;
    }

}
