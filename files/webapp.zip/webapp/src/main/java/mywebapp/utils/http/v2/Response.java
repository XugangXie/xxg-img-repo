package mywebapp.utils.http.v2;

import lombok.Data;

/**
 * @Description:
 * @Author: xiexugang
 * @Datetime: 2025-06-20 11:51:04
 **/
@Data
public class Response<T> {
    private Integer statusCode = 200;
    private Boolean isSuccess = true;
    private String errorMsg;
    private T output;
}
