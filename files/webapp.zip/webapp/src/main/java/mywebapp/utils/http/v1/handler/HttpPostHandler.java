package mywebapp.utils.http.v1.handler;

import mywebapp.utils.http.v1.entity.HttpResult;

import java.util.Map;

/**
 * http POST handler.
 */
public interface HttpPostHandler {

  /**
   * do post[xml].
   *
   * @param url     url.
   * @param xml     xml.
   * @param timeout timeout.
   * @return http result.
   */
  HttpResult doPost(String url, String xml, int timeout);

  /**
   * do post[xml, retry].
   *
   * @param url      url.
   * @param xml      xml.
   * @param timeout  timeout.
   * @param tryCount try count.
   * @param interval try interval.
   * @return http result.
   */
  HttpResult doPost(String url, String xml, int timeout, int tryCount, int interval);

  /**
   * do post[body type: String/File/InputStream/byte[]/ContentBody)].
   *
   * @param url     url.
   * @param bodyMap body map.
   * @param timeout timeout.
   * @return http result.
   */
  HttpResult doPost(String url, Map<String, Object> bodyMap, int timeout);

  /**
   * do post[body type: String/File/InputStream/byte[]/ContentBody), retry].
   *
   * @param url     url.
   * @param bodyMap body map.
   * @param timeout timeout.
   * @param tryCount try count.
   * @param interval try interval.
   * @return http result.
   */
  HttpResult doPost(String url, Map<String, Object> bodyMap, int timeout, int tryCount, int interval);
}
