package mywebapp.utils.http.v1.impl;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import mywebapp.utils.http.v1.handler.HttpPostHandler;
import mywebapp.utils.http.v1.entity.HttpResult;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Impl of {@link HttpPostHandler}.
 */
@Component
@Slf4j
public class HttpPostHandlerImpl implements HttpPostHandler {

  @Override
  public HttpResult doPost(String url, String xml, int timeout) {
    return this.handle(url, xml, timeout);
  }

  @Override
  public HttpResult doPost(String url, String xml, int timeout, int tryCount, int interval) {
    return this.handle(url, xml, timeout, tryCount, interval);
  }

  @Override
  public HttpResult doPost(String url, Map<String, Object> bodyMap, int timeout) {
    return this.handle(url, bodyMap, timeout);
  }

  @Override
  public HttpResult doPost(String url, Map<String, Object> bodyMap, int timeout, int tryCount, int interval) {
    return this.handle(url, bodyMap, timeout, tryCount, interval);
  }

  private HttpResult handle(String url, Object obj, int timeout, int tryCount, int interval) {
    if (tryCount <= 1) {
      return this.handle(url, obj, timeout);
    }
    HttpResult result = null;
    for (int i = 1; i <= tryCount; i++) {
      log.info("Post trying {} time", i);
      result = this.handle(url, obj, timeout);
      if (result.getResponse().isOkFlag()) {
        break;
      }
      if (interval > 0) {
        try {
          Thread.sleep(interval);
        } catch (InterruptedException e) {
          log.error(e.getMessage(), e);
        }
      }
    }
    return result;
  }

  private HttpResult handle(String url, Object obj, int timeout) {
    HttpResult httpResult = HttpResult.builder()
      .request(new HttpResult.Request(url, obj))
      .response(new HttpResult.Response(false, 0))
      .build();
    //build Post request
    HttpPost httpPost = new HttpPost(url);
    RequestConfig requestConfig = RequestConfig.custom()
      .setConnectTimeout(timeout * 1000)
      .setConnectionRequestTimeout(timeout * 1000)
      .setSocketTimeout(timeout * 1000)
      .build();
    httpPost.setConfig(requestConfig);
    // set post body
    if (obj != null) {
      if (obj instanceof String) {
        String xml = (String) obj;
        if (!StringUtils.isEmpty(xml)) {
          httpPost.setHeader("Content-Type", "application/json");
          StringEntity reqEntity = new StringEntity(xml, "UTF-8");
          httpPost.setEntity(reqEntity);
        }
      } else if (obj instanceof Map) {
        Map<String, Object> bodyMap = (Map) obj;
        if (bodyMap != null && bodyMap.size() > 0) {
          HttpEntity httpEntity = this.buildBody(bodyMap);
          httpPost.setEntity(httpEntity);
        }
      }
    }
    //execute Post request and response
    CloseableHttpClient httpClient = HttpClients.createDefault();
    CloseableHttpResponse response = null;
    try {
      response = httpClient.execute(httpPost);
      int statusCode = response.getStatusLine().getStatusCode();
      if (statusCode == 200 || statusCode == 201) {
        httpResult.getResponse().setOkFlag(true);
      }
      //set statusCode,responseContent
      String strResult = EntityUtils.toString(response.getEntity(), "UTF-8");
      httpResult.getResponse().setContent(strResult);
      httpResult.getResponse().setStatusCode(statusCode);
    } catch (IOException ex) {
      String errorMsg = String.format("http connection failed: %s", ex.getMessage());
      log.error(errorMsg, ex);
      httpResult.getResponse().setErrorMsg(errorMsg);
    } finally {
      if (response != null) {
        try {
          response.close();
        } catch (IOException ex) {
          String errorMsg = String.format("request response closed exception: %s", ex.getMessage());
          log.error(errorMsg, ex);
        }
      }
    }
    httpResult.getResponse().setTime(LocalDateTime.now());
    log.debug("doPost finished, httpResult: {}", httpResult);
    log.debug("doPost finished, request url: {}, request body: {}, response result: {}",
      httpResult.getRequest().getUrl(), httpResult.getRequest().getParams(), httpResult.getResponse().isOkFlag());
    return httpResult;
  }

  private HttpEntity buildBody(Map<String, Object> bodyMap) {
    MultipartEntityBuilder entityBuilder = MultipartEntityBuilder.create();
    entityBuilder.setCharset(Charset.forName("UTF-8"));
    for (String key : bodyMap.keySet()) {
      Object value = bodyMap.get(key);
      if (value instanceof String) {
        entityBuilder.addTextBody(key, (String) value);
      } else if (value instanceof File) {
        entityBuilder.addBinaryBody(key, (File) value);
      } else if (value instanceof InputStream) {
        entityBuilder.addBinaryBody(key, (InputStream) value);
      } else if (value instanceof byte[]) {
        entityBuilder.addBinaryBody(key, (byte[]) value);
      } else if (value instanceof ContentBody) {
        entityBuilder.addPart(key, (ContentBody) value);
      }
    }
    return entityBuilder.build();
  }
}
