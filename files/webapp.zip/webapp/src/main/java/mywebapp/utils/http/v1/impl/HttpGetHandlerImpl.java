package mywebapp.utils.http.v1.impl;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;
import mywebapp.utils.http.v1.handler.HttpGetHandler;
import mywebapp.utils.http.v1.entity.HttpResult;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Impl of {@link HttpGetHandler}.
 */
@Component
@Slf4j
public class HttpGetHandlerImpl implements HttpGetHandler {

  @Override
  public HttpResult doGet(String url, int timeout) {
    return this.handle(url, null, timeout);
  }

  @Override
  public HttpResult doGet(String url, int timeout, int tryCount, int interval) {
    return this.handle(url, null, timeout, tryCount, interval);
  }

  @Override
  public HttpResult doGet(String url, Map<String, String> params, int timeout) {
    return this.handle(url, params, timeout);
  }

  @Override
  public HttpResult doGet(String url, Map<String, String> params, int timeout, int tryCount, int interval) {
    return this.handle(url, params, timeout, tryCount, interval);
  }

  @Override
  public String addUrlParams(String url, Map<String, String> params) {
    return this.buildUrlParams(url, params);
  }

  private HttpResult handle(String url, Map<String, String> params, int timeout, int tryCount, int interval) {
    if (tryCount <= 1) {
      return this.handle(url, params, timeout);
    }
    HttpResult result = null;
    for (int i = 1; i <= tryCount; i++) {
      log.info("Get trying {} time", i);
      result = this.handle(url, params, timeout);
      if (result.getResponse().isOkFlag()) {
        break;
      }
      if (interval > 0) {
        try {
          Thread.sleep(interval);
        } catch (InterruptedException e) {
          log.error(e.getMessage(), e);
        }
      }
    }
    return result;
  }

  private HttpResult handle(String url, Map<String, String> params, int timeout) {
    HttpResult httpResult = HttpResult.builder()
      .request(new HttpResult.Request(url, params))
      .response(new HttpResult.Response(false, 0))
      .build();
    //build Get request
    HttpGet httpGet = new HttpGet(this.buildUrlParams(url, params));
    RequestConfig requestConfig = RequestConfig.custom()
      .setConnectTimeout(timeout * 1000)
      .setConnectionRequestTimeout(timeout * 1000)
      .setSocketTimeout(timeout * 1000)
      .build();
    httpGet.setConfig(requestConfig);
    //execute Get request and response
    CloseableHttpClient httpClient = HttpClients.createDefault();
    CloseableHttpResponse response = null;
    try {
      response = httpClient.execute(httpGet);
      int statusCode = response.getStatusLine().getStatusCode();
      if (statusCode == 200 || statusCode == 201) {
        httpResult.getResponse().setOkFlag(true);
      }
      //set statusCode,responseContent
      String strResult = EntityUtils.toString(response.getEntity(), "UTF-8");
      httpResult.getResponse().setContent(strResult);
      httpResult.getResponse().setStatusCode(statusCode);
    } catch (IOException ex) {
      String errorMsg = String.format("http connection failed: %s", ex.getMessage());
      log.error(errorMsg, ex);
      httpResult.getResponse().setErrorMsg(errorMsg);
    } finally {
      if (response != null) {
        try {
          response.close();
        } catch (IOException ex) {
          String errorMsg = String.format("request response closed exception: %s", ex.getMessage());
          log.error(errorMsg, ex);
        }
      }
    }
    httpResult.getResponse().setTime(LocalDateTime.now());
    log.debug("doGet finished, httpResult: {}", httpResult);
    log.debug("doGet finished, request url: {}, request params: {}, response result: {}",
      httpResult.getRequest().getUrl(), httpResult.getRequest().getParams(), httpResult.getResponse().isOkFlag());
    return httpResult;
  }

  private String buildUrlParams(String url, Map<String, String> params) {
    URIBuilder uriBuilder;
    try {
      uriBuilder = new URIBuilder(url);
    } catch (URISyntaxException e) {
      throw new RuntimeException(e);
    }
    if (params != null && params.size() > 0) {
      for (String key : params.keySet()) {
        uriBuilder.addParameter(key, params.get(key));
      }
    }
    return uriBuilder.toString();
  }
}
