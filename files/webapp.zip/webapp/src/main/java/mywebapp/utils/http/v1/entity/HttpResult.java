package mywebapp.utils.http.v1.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HttpResult {
  private Request request;
  private Response response;

  @Builder
  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Request {
    private String url;
    private Object params;
    private LocalDateTime time;

    public Request(String url, Object params) {
      this.url = url;
      this.params = params;
      this.time = LocalDateTime.now();
    }
  }

  @Builder
  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Response {
    private boolean okFlag;
    private String errorMsg;
    private LocalDateTime time;
    private int statusCode;
    private String content;

    public Response(boolean okFlag, int statusCode) {
      this.okFlag = okFlag;
      this.statusCode = statusCode;
    }

    public Response(boolean okFlag, String errorMsg) {
      this.okFlag = okFlag;
      this.errorMsg = errorMsg;
    }
  }
}
