/**
 org.w3c.dom.Document 是 Java 标准库中提供的 DOM (Document Object Model) 解析接口，
 属于 JAXP (Java API for XML Processing) 的一部分。它提供了一种标准的方式来解析和操作 XML 文档。
 */
package mywebapp.utils.xml;