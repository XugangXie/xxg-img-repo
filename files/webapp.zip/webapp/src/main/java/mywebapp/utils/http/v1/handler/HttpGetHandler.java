package mywebapp.utils.http.v1.handler;

import mywebapp.utils.http.v1.entity.HttpResult;

import java.util.Map;

/**
 * http GET handler.
 */
public interface HttpGetHandler {

  /**
   * do get.
   *
   * @param url     url.
   * @param timeout time out.
   * @return http result.
   */
  HttpResult doGet(String url, int timeout);

  /**
   * do get[retry].
   *
   * @param url      url.
   * @param timeout  time out.
   * @param tryCount try count.
   * @param interval try interval.
   * @return http result.
   */
  HttpResult doGet(String url, int timeout, int tryCount, int interval);

  /**
   * do get[add params].
   *
   * @param url     url.
   * @param params  add params into url.
   * @param timeout time out.
   * @return http result.
   */
  HttpResult doGet(String url, Map<String, String> params, int timeout);

  /**
   * do get[add params, retry].
   *
   * @param url      url.
   * @param params   add params into url.
   * @param timeout  time out.
   * @param tryCount try count.
   * @param interval try interval.
   * @return http result.
   */
  HttpResult doGet(String url, Map<String, String> params, int timeout, int tryCount, int interval);

  /**
   * add params into url.
   *
   * @param url    url.
   * @param params params.
   * @return url str.
   */
  String addUrlParams(String url, Map<String, String> params);
}
