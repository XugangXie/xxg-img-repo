cd /d %~dp0

call mvn -e -DskipTests=true clean package

pause