
## 说明
- springboot 2.x.x 集成 mybatis-plus的基本用法

## 注意点：
1. 对于批量插入，需要在<insert id="batchInsert"> 标签里，配置成如下：
```xml
<insert id="batchInsert" parameterType="java.util.List" keyColumn="id" keyProperty="id" useGeneratedKeys="true">
```

2. 对于批量更新，需要在jdbc url 里面，追加参数： `&allowMultiQueries=true`


## 亮点：
1.使用logback-spring.xml，输出日志；使用springProfiles标签，来区别环境对应的日志输出方式；
- dev环境，启动命令：java -jar -Dspring.profiles.active=dev xx.jar --env.log.path=D:/log
这个环境的日志，是输出到自定义的Console，里面的traceId，来自于：（这里没用自定义的MDC）

```java
String traceId = this.traceIdProvider.getTraceId();
具体参考：springbootmybatisplus.infrastructure.trace.web.HttpPayloadFilter.doFilterInternal
```

- uat或prod环境，启动命令：java -jar -Dspring.profiles.active=uat xx.jar --env.log.path=D:/log
这个环境的日志，是输出到标准的Console，所以没有traceId；同时输出到info、error、warn各自级别下，对应的日志文件里，有traceId（这里没用自定义的MDC）
来自于`String traceId = this.traceIdProvider.getTraceId();`；

最突出的是，网络请求的access-log，也可以输出到  request/access.log 日志中，具体实现类：`springbootmybatisplus.infrastructure.trace.web.HttpPayloadFilter.doFilterInternal`

2.使用异步写日志文件的方式：
```xml
		<root level="INFO">
			<!-- CONSOLE 是库中标准的控制台输出 -->
			<appender-ref ref="CONSOLE" />
			
			<!-- 异步写入日志 -->
			<appender-ref ref="ASYNC_FILE_INFO" />
			<appender-ref ref="ASYNC_FILE_WARN" />
			<appender-ref ref="ASYNC_FILE_ERROR" />
			
		</root>
```
